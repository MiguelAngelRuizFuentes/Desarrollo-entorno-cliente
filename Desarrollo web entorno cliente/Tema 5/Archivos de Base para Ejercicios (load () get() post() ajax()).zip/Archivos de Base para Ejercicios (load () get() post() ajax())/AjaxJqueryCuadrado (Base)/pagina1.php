<?php

$cuadrado=$_REQUEST['numero']*$_REQUEST['numero'];

echo $cuadrado;

?>